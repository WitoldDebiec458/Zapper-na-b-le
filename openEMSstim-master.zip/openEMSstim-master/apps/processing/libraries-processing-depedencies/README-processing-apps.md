# android using processing: openEMSstim-control
This libraries are just here as they are needed for the processing sketches. All lib files remain with original licence. 


