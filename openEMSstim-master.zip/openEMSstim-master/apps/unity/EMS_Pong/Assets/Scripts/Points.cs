﻿using UnityEngine;
using System.Collections;

public class Points : MonoBehaviour {

	public int points;

	// Use this for initialization
	void Start () {
		int points = 0;
		//Debug.Log (points);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
