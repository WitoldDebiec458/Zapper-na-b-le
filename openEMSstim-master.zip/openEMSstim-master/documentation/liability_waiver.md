## Liability Waiver

By using REPOSITORY, YOU (the person using this) are agreeing to the following:

1. When using any code, video, know-how, hardware, data from this repository (hereby denoted as REPOSITORY) you are agreeing to: for yourself, your heirs, assigns, family, personal representatives and next to kin, TO HEREBY RELEASE WAIVE, DISCHARGE, AND COVENANT TO NOT SUE THE AUTHORS of REPOSITORY, and each of its respective current and former successors, predecessors, parent, subsidiaries, affiliate entities, related companies, employees, offices, directors, owners, shareholders, partners, agents and advertisers. , WITH RESPECT TO ANY AND ALL INJURY, DISABILITY, DEATH, OR LOSS OR DAMAGE TO PERSON OR PROPERTY incident to your participation in and use of REPOSITORY and related events of activities, including, but not limited to, any and all liabilities resulting from any medical or physical condition your may have, WHETHER ARISING FROM THE NEGLIGENCE OF THE RELEASED PARTIES, YOUR OWN NEGLIGENCE, OR OTHERWISE, to the fullest extent permitted by law. 

2. You DO HEREBY INDEMNIFY AND HOLD HARMLESS each of the above parties (the AUTHORS of REPOSITORY) from and against any and all liabilities incident to your participation and use of REPOSITORY, and related events and activities, including, but not limited to, any and all liabilities resulting from any medical or physical condition you may have, WHETHER ARISING FROM THE NEGLIGENCE OF THE RELEASED PARTIES, YOUR OWN NEGLIGENCE, OR OTHERWISE, to the fullest extent 
permitted by law.

3. You understand and agree that: there are exists risk of injury from using Electrical Muscle Stimulation and this hardware (from REPOSITORY), although the risk may be reduced somewhat by particular rules, equipment, and personal discipline, the risk or injury to participants, including yourself, and of you causing injury to other participants, still exists. 

4. KNOWINGLY AND FREELY ASSUME ALL SUCH RISKS, both known and unknown, EVEN IF ARISING FRIOM THE NEGLIGENCE OF THE RELEASED PARTIES, yourself or others, and assume full responsibility for your use of REPOSITORY. 

5. Should any of the above parties (AUTHORS of REPOSITORY) or anyone acting in their behalf be required to incur attorney’s fees or costs to enforce this agreement, YOU agree to indemnify and hold them harmless for all such fees and costs.



