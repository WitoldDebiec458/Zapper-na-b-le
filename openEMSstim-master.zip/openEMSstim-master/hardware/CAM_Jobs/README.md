# openEMSstim: manufacturing a board

## Tested services 
*  www.elecrow.com: generate the Gerber files using the CAM job **Elecrow_Gerber_Generater_DrillAlign_Tested.cam**, for the silkscreen add also the layer "Name"

### License and Liability

Please refer to the liability waiver (in documentation/liability_waiver.md).

Please refer to the license (in /license.md)

